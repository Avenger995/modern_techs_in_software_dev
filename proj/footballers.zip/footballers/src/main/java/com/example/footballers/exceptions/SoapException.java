package com.example.footballers.exceptions;

public class SoapException extends Exception {

    public SoapException(String message, Throwable cause) {
        super(message, cause);
    }

}
