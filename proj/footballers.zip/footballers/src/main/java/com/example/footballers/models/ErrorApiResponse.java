package com.example.footballers.models;

public class ErrorApiResponse {
    public String ErrorMsg;

    public String getErrorMsg() {
        return ErrorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        ErrorMsg = errorMsg;
    }
}
